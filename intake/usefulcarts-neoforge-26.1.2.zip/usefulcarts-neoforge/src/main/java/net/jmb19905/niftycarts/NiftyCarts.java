package net.jmb19905.niftycarts;

import net.jmb19905.niftycarts.advancement.NCCriteriaTriggers;
import net.jmb19905.niftycarts.container.PlowMenu;
import net.jmb19905.niftycarts.container.SeedDrillMenu;
import net.jmb19905.niftycarts.container.WagonMenu;
import net.jmb19905.niftycarts.entity.*;
import net.jmb19905.niftycarts.entity.ai.goal.AvoidCartGoal;
import net.jmb19905.niftycarts.entity.ai.goal.PullCartGoal;
import net.jmb19905.niftycarts.entity.ai.goal.RideCartGoal;
import net.jmb19905.niftycarts.item.CartItem;
import net.jmb19905.niftycarts.network.clientbound.UpdateDrawnPayload;
import net.jmb19905.niftycarts.network.serverbound.*;
import net.jmb19905.niftycarts.util.NiftyWorld;
import net.jmb19905.niftycarts.util.NiftyGoalAdder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.stats.StatFormatter;
import net.minecraft.stats.Stats;
import net.minecraft.tags.TagKey;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.*;
import net.minecraft.world.flag.FeatureFlag;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.properties.WoodType;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.CreativeModeTab;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.server.ServerStartedEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import net.neoforged.neoforge.registries.RegisterEvent;
import org.jetbrains.annotations.NotNull;
import oshi.util.tuples.Triplet;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Function;

@Mod(NiftyCarts.MOD_ID)
public class NiftyCarts {
	public static final String MOD_ID = "usefulcarts";

	public static Item WHEEL;
	private static final Function<Triplet<WoodType, String, FeatureFlag[]>, CartItem> CART_ITEM_SUPPLIER =
            (triplet) ->
                    register(triplet.getA().name() + "_" + triplet.getB(), prop ->
                            new CartItem(triplet.getA(), triplet.getB(), prop.stacksTo(1).requiredFeatures(triplet.getC())));
	public static final Map<WoodType, CartItem> SUPPLY_CART = new HashMap<>();
	public static final Map<WoodType, CartItem> HAND_CART = new HashMap<>();
	public static final Map<WoodType, CartItem> PLOW = new HashMap<>();
	public static final Map<WoodType, CartItem> ANIMAL_CART = new HashMap<>();
	public static final Map<WoodType, CartItem> SEED_DRILL = new HashMap<>();
	public static final Map<WoodType, CartItem> REAPER = new HashMap<>();
    public static final Map<WoodType, CartItem> WAGON = new HashMap<>();

	public static final WoodType[] VANILLA_WOOD_TYPES = {
			WoodType.OAK,
			WoodType.SPRUCE,
			WoodType.BIRCH,
			WoodType.ACACIA,
			WoodType.CHERRY,
			WoodType.JUNGLE,
			WoodType.DARK_OAK,
			WoodType.PALE_OAK,
			WoodType.CRIMSON,
			WoodType.WARPED,
			WoodType.MANGROVE,
			WoodType.BAMBOO
	};

	private static void registerItems() {
		WHEEL = register("wheel", Item::new);
		for (WoodType woodType : VANILLA_WOOD_TYPES) {
			FeatureFlag[] flags = {};
			SUPPLY_CART.put(woodType, CART_ITEM_SUPPLIER.apply(new Triplet<>(woodType, "supply_cart", flags)));
			HAND_CART.put(woodType, CART_ITEM_SUPPLIER.apply(new Triplet<>(woodType, "hand_cart", flags)));
			PLOW.put(woodType, CART_ITEM_SUPPLIER.apply(new Triplet<>(woodType, "plow", flags)));
			SEED_DRILL.put(woodType, CART_ITEM_SUPPLIER.apply(new Triplet<>(woodType, "seed_drill", flags)));
			REAPER.put(woodType, CART_ITEM_SUPPLIER.apply(new Triplet<>(woodType, "reaper", flags)));
			ANIMAL_CART.put(woodType, CART_ITEM_SUPPLIER.apply(new Triplet<>(woodType, "animal_cart", flags)));
            WAGON.put(woodType, CART_ITEM_SUPPLIER.apply(new Triplet<>(woodType, "wagon", flags)));
		}
	}

	public static MinecraftServer server = null;

	public static final Identifier ATTACH_SOUND_ID = resLoc("entity.cart.attach");
	public static final Identifier DETACH_SOUND_ID = resLoc("entity.cart.detach");
	public static final Identifier PLACE_SOUND_ID = resLoc("entity.cart.place");

	public static SoundEvent ATTACH_SOUND = SoundEvent.createVariableRangeEvent(ATTACH_SOUND_ID);
	public static SoundEvent DETACH_SOUND = SoundEvent.createVariableRangeEvent(DETACH_SOUND_ID);
	public static SoundEvent PLACE_SOUND = SoundEvent.createVariableRangeEvent(PLACE_SOUND_ID);

	public static EntityType<@NotNull SupplyCartEntity> SUPPLY_CART_ENTITY;

	public static EntityType<@NotNull AnimalCartEntity> ANIMAL_CART_ENTITY;

	public static EntityType<@NotNull PlowEntity> PLOW_ENTITY;

	public static EntityType<@NotNull HandCartEntity> HAND_CART_ENTITY;

	public static EntityType<@NotNull SeedDrillEntity> SEED_DRILL_ENTITY;

	public static EntityType<@NotNull ReaperCartEntity> REAPER_ENTITY;

	public static EntityType<@NotNull WagonEntity> WAGON_ENTITY;

	public static EntityType<@NotNull PostilionEntity> POSTILION_ENTITY;

	public static final NiftyGoalAdder<Mob> MOB_GOAL_ADDER = NiftyGoalAdder.mobGoal(Mob.class)
			.add(1, PullCartGoal::new)
			.add(1, RideCartGoal::new)
			.build();

	public static final NiftyGoalAdder<PathfinderMob> PATHFINDER_GOAL_ADDER = NiftyGoalAdder.mobGoal(PathfinderMob.class)
			.add(3, mob -> new AvoidCartGoal<>(mob, SupplyCartEntity.class, 3.0f, 0.5f))
			.add(3, mob -> new AvoidCartGoal<>(mob, PlowEntity.class, 3.0f, 0.5f))
            .add(3, mob -> new AvoidCartGoal<>(mob, SeedDrillEntity.class, 3.0f, 0.5f))
            .add(3, mob -> new AvoidCartGoal<>(mob, ReaperCartEntity.class, 3.0f, 0.5f))
			.build();

	public static final MenuType<@NotNull PlowMenu> PLOW_MENU_TYPE = new MenuType<>(PlowMenu::new, FeatureFlags.DEFAULT_FLAGS);
	public static final MenuType<@NotNull SeedDrillMenu> SEED_DRILL_MENU_TYPE = new MenuType<>(SeedDrillMenu::new, FeatureFlags.DEFAULT_FLAGS);
    public static final MenuType<@NotNull WagonMenu> WAGON_9x4_MENU_TYPE = new MenuType<>((i, inv) -> new WagonMenu(NiftyCarts.WAGON_9x4_MENU_TYPE, i, inv, new SimpleContainer(4 * 9), 4), FeatureFlags.DEFAULT_FLAGS);
    public static final MenuType<@NotNull WagonMenu> WAGON_9x8_MENU_TYPE = new MenuType<>((i, inv) -> new WagonMenu(NiftyCarts.WAGON_9x8_MENU_TYPE, i, inv, new SimpleContainer(8 * 9), 8), FeatureFlags.DEFAULT_FLAGS);
    public static final MenuType<@NotNull WagonMenu> WAGON_12x9_MENU_TYPE = new MenuType<>((i, inv) -> new WagonMenu(NiftyCarts.WAGON_12x9_MENU_TYPE, i, inv, new SimpleContainer(12 * 9), 12), FeatureFlags.DEFAULT_FLAGS);

    /** Stat ids are independent of entity registration order, so they are fixed up front. */
    private static final Map<String, Identifier> PULL_STATS = new LinkedHashMap<>();
    static {
        for (String cart : new String[]{"supply_cart", "hand_cart", "animal_cart", "plow", "reaper", "seed_drill", "wagon"}) {
            PULL_STATS.put(cart, Identifier.fromNamespaceAndPath(MOD_ID, cart + "_pull_cm"));
        }
    }
    /** Filled in once entity types are registered. */
    public static final Map<EntityType<?>, Identifier> CART_PULL_CM = new HashMap<>();

    public static final Identifier RIDE_CART_CM = Identifier.fromNamespaceAndPath(MOD_ID, "ride_cart_cm");
    public static final Identifier STEER_ANIMAL_CART_CM = Identifier.fromNamespaceAndPath(MOD_ID, "steer_animal_cart_cm");
    public static final Identifier STEER_REAPER_CM = Identifier.fromNamespaceAndPath(MOD_ID, "steer_reaper_cm");

	public static final TagKey<@NotNull Block> PLOW_BREAKABLE_HOE = TagKey.create(Registries.BLOCK, NiftyCarts.resLoc("plow_breakable/hoe"));
	public static final TagKey<@NotNull Block> PLOW_BREAKABLE_SHOVEL = TagKey.create(Registries.BLOCK, NiftyCarts.resLoc("plow_breakable/shovel"));
	public static final TagKey<@NotNull Block> PLOW_BREAKABLE_AXE = TagKey.create(Registries.BLOCK, NiftyCarts.resLoc("plow_breakable/axe"));
    public static final TagKey<@NotNull Block> REAPER_HARVESTABLE = TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath(NiftyCarts.MOD_ID, "reaper_harvestable"));
	public static final TagKey<@NotNull Item> SEED_DRILL_PLANTABLE = TagKey.create(Registries.ITEM, NiftyCarts.resLoc("seed_drill_plantable"));

    @SuppressWarnings("SameParameterValue")
    private static void registerStat(Identifier id, StatFormatter formatter) {
        Registry.register(BuiltInRegistries.CUSTOM_STAT, id, id);
        Stats.CUSTOM.get(id, formatter);
    }

	private static void registerEntityTypes() {
		SUPPLY_CART_ENTITY = register("supply_cart", EntityType.Builder.of(SupplyCartEntity::new, MobCategory.MISC).sized(1.5f, 1.4f));
		ANIMAL_CART_ENTITY = register("animal_cart", EntityType.Builder.of(AnimalCartEntity::new, MobCategory.MISC).sized(1.3f, 1.4f));
		PLOW_ENTITY = register("plow", EntityType.Builder.of(PlowEntity::new, MobCategory.MISC).sized(1.3f, 1.4f));
		HAND_CART_ENTITY = register("hand_cart", EntityType.Builder.of(HandCartEntity::new, MobCategory.MISC).sized(1.3f, 1.1f));
		SEED_DRILL_ENTITY = register("seed_drill", EntityType.Builder.of(SeedDrillEntity::new, MobCategory.MISC).sized(1.3f, 1.4f));
		REAPER_ENTITY = register("reaper", EntityType.Builder.of(ReaperCartEntity::new, MobCategory.MISC).sized(1.3f, 1.4f));
		WAGON_ENTITY = register("wagon", EntityType.Builder.of(WagonEntity::new, MobCategory.MISC).sized(2.5f, 3f));
		POSTILION_ENTITY = register("postilion", EntityType.Builder.of(PostilionEntity::new, MobCategory.MISC).sized(0.25f, 0.25f).noSummon().noSave());
		CART_PULL_CM.clear();
		CART_PULL_CM.put(SUPPLY_CART_ENTITY, PULL_STATS.get("supply_cart"));
		CART_PULL_CM.put(HAND_CART_ENTITY, PULL_STATS.get("hand_cart"));
		CART_PULL_CM.put(ANIMAL_CART_ENTITY, PULL_STATS.get("animal_cart"));
		CART_PULL_CM.put(PLOW_ENTITY, PULL_STATS.get("plow"));
		CART_PULL_CM.put(REAPER_ENTITY, PULL_STATS.get("reaper"));
		CART_PULL_CM.put(SEED_DRILL_ENTITY, PULL_STATS.get("seed_drill"));
		CART_PULL_CM.put(WAGON_ENTITY, PULL_STATS.get("wagon"));
	}

	public NiftyCarts(IEventBus modBus, ModContainer container) {
		container.registerConfig(ModConfig.Type.COMMON, NiftyCartsConfig.spec());
		container.registerConfig(ModConfig.Type.CLIENT, NiftyCartsConfig.clientSpec());

		modBus.addListener(NiftyCarts::onRegister);
		modBus.addListener(NiftyCarts::onRegisterPayloads);
		modBus.addListener(NiftyCarts::onEntityAttributes);

		NeoForge.EVENT_BUS.addListener((ServerStartedEvent e) -> server = e.getServer());
		NeoForge.EVENT_BUS.addListener((ServerStoppedEvent e) -> server = null);
		NeoForge.EVENT_BUS.addListener(NiftyCarts::onServerTick);
		NeoForge.EVENT_BUS.addListener(NiftyCarts::onEntityInteract);
		NeoForge.EVENT_BUS.addListener(NiftyCarts::onEntityJoin);
	}

	private static void onRegister(RegisterEvent event) {
		// Vanilla Registry.register is fine here: NeoForge unfreezes registries around this event.
		if (event.getRegistryKey().equals(Registries.SOUND_EVENT)) {
			Registry.register(BuiltInRegistries.SOUND_EVENT, ATTACH_SOUND_ID, ATTACH_SOUND);
			Registry.register(BuiltInRegistries.SOUND_EVENT, DETACH_SOUND_ID, DETACH_SOUND);
			Registry.register(BuiltInRegistries.SOUND_EVENT, PLACE_SOUND_ID, PLACE_SOUND);
		} else if (event.getRegistryKey().equals(Registries.ENTITY_TYPE)) {
			registerEntityTypes();
		} else if (event.getRegistryKey().equals(Registries.ITEM)) {
			registerItems();
		} else if (event.getRegistryKey().equals(Registries.MENU)) {
			Registry.register(BuiltInRegistries.MENU, resLoc("plow"), PLOW_MENU_TYPE);
			Registry.register(BuiltInRegistries.MENU, resLoc("seed_drill"), SEED_DRILL_MENU_TYPE);
			Registry.register(BuiltInRegistries.MENU, resLoc("chest_four_rows"), WAGON_9x4_MENU_TYPE);
			Registry.register(BuiltInRegistries.MENU, resLoc("chest_eight_rows"), WAGON_9x8_MENU_TYPE);
			Registry.register(BuiltInRegistries.MENU, resLoc("chest_quad"), WAGON_12x9_MENU_TYPE);
		} else if (event.getRegistryKey().equals(Registries.CUSTOM_STAT)) {
			for (Identifier stat : PULL_STATS.values()) {
				registerStat(stat, StatFormatter.DISTANCE);
			}
			registerStat(RIDE_CART_CM, StatFormatter.DISTANCE);
			registerStat(STEER_ANIMAL_CART_CM, StatFormatter.DISTANCE);
			registerStat(STEER_REAPER_CM, StatFormatter.DISTANCE);
		} else if (event.getRegistryKey().equals(BuiltInRegistries.TRIGGER_TYPES.key())) {
			NCCriteriaTriggers.register();
		} else if (event.getRegistryKey().equals(Registries.CREATIVE_MODE_TAB)) {
			Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, resLoc("usefulcarts"),
					CreativeModeTab.builder()
							.title(Component.translatable("itemGroup.usefulcarts"))
							.icon(() -> new ItemStack(SUPPLY_CART.get(WoodType.OAK)))
							.displayItems((params, output) -> {
								output.accept(WHEEL);
								for (WoodType woodType : VANILLA_WOOD_TYPES) {
									output.accept(SUPPLY_CART.get(woodType));
									output.accept(PLOW.get(woodType));
									output.accept(SEED_DRILL.get(woodType));
									output.accept(REAPER.get(woodType));
									output.accept(ANIMAL_CART.get(woodType));
									output.accept(HAND_CART.get(woodType));
									output.accept(WAGON.get(woodType));
								}
							})
							.build());
		}
	}

	private static void onRegisterPayloads(RegisterPayloadHandlersEvent event) {
		final PayloadRegistrar registrar = event.registrar("1");
		registrar.playToServer(ActionKeyPayload.TYPE, ActionKeyPayload.CODEC, (payload, ctx) -> ActionKeyPayload.handle((ServerPlayer) ctx.player()));
		registrar.playToServer(OpenSupplyCartPayload.TYPE, OpenSupplyCartPayload.CODEC, (payload, ctx) -> OpenSupplyCartPayload.handle((ServerPlayer) ctx.player()));
		registrar.playToServer(ToggleSlowPayload.TYPE, ToggleSlowPayload.CODEC, (payload, ctx) -> ToggleSlowPayload.handle((ServerPlayer) ctx.player()));
		registrar.playToServer(RequestCartUpdatePayload.TYPE, RequestCartUpdatePayload.CODEC, (payload, ctx) -> RequestCartUpdatePayload.handle(payload, (ServerPlayer) ctx.player()));
		registrar.playToServer(CoachmanMovePayload.TYPE, CoachmanMovePayload.CODEC, (payload, ctx) -> CoachmanMovePayload.handle(payload, (ServerPlayer) ctx.player()));
		// Clientbound: handler is attached on the client in NiftyCartsClient (RegisterClientPayloadHandlersEvent).
		registrar.playToClient(UpdateDrawnPayload.TYPE, UpdateDrawnPayload.CODEC);
	}

	private static void onEntityAttributes(EntityAttributeCreationEvent event) {
		event.put(POSTILION_ENTITY, LivingEntity.createLivingAttributes().build());
	}

	private static void onServerTick(ServerTickEvent.Post event) {
		final MinecraftServer s = event.getServer();
		for (ResourceKey<@NotNull Level> levelKey : s.levelKeys()) {
			NiftyWorld.getServer(s, levelKey).tick(s.getLevel(levelKey));
		}
	}

	private static void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
		final Entity rider = event.getTarget().getControllingPassenger();
		if (rider instanceof PostilionEntity) {
			rider.stopRiding();
		}
	}

	private static void onEntityJoin(EntityJoinLevelEvent event) {
		// Fabric's ServerEntityEvents.ENTITY_LOAD is server-only; this event fires on both sides.
		if (event.getLevel().isClientSide()) return;
		MOB_GOAL_ADDER.onEntityJoinWorld(event.getEntity());
		PATHFINDER_GOAL_ADDER.onEntityJoinWorld(event.getEntity());
	}

	public static <T extends Entity> EntityType<@NotNull T> register(String id, EntityType.Builder<@NotNull T> builder) {
		ResourceKey<@NotNull EntityType<?>> key = ResourceKey.create(Registries.ENTITY_TYPE, resLoc(id));
		return Registry.register(BuiltInRegistries.ENTITY_TYPE, key, builder.build(key));
	}

	public static <I extends Item> I register(String id, Function<Item.Properties, I> function) {
		ResourceKey<@NotNull Item> key = ResourceKey.create(Registries.ITEM, resLoc(id));
		I item = function.apply(new Item.Properties().setId(key));
		return Registry.register(BuiltInRegistries.ITEM, key, item);
	}

	public static Identifier resLoc(String name) {
		return Identifier.fromNamespaceAndPath(MOD_ID, name);
	}

}