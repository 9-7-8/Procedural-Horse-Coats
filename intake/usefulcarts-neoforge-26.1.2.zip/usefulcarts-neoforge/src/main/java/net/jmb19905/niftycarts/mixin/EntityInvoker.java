package net.jmb19905.niftycarts.mixin;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/** Replaces two Fabric access-widener entries for protected Entity methods. */
@Mixin(Entity.class)
public interface EntityInvoker {
    @Invoker("makeBoundingBox")
    AABB usefulcarts$makeBoundingBox();

    @Invoker("setRot")
    void usefulcarts$setRot(float yRot, float xRot);
}
