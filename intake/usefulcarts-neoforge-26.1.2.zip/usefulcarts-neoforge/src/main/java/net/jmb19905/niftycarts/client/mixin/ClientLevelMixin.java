package net.jmb19905.niftycarts.client.mixin;

import net.neoforged.neoforge.client.network.ClientPacketDistributor;
import net.jmb19905.niftycarts.entity.AbstractDrawnEntity;
import net.jmb19905.niftycarts.network.serverbound.RequestCartUpdatePayload;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientLevel.class)
public class ClientLevelMixin {

    @Inject(method = "addEntity", at = @At("TAIL"))
    public void addEntity(Entity entity, CallbackInfo ci) {
        if (entity instanceof AbstractDrawnEntity d) {
            ClientPacketDistributor.sendToServer(new RequestCartUpdatePayload(d.getId()));
        }
    }

}
