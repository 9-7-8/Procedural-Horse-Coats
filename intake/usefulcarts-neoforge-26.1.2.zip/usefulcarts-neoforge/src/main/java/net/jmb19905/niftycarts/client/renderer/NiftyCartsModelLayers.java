package net.jmb19905.niftycarts.client.renderer;

import net.jmb19905.niftycarts.NiftyCarts;
import net.minecraft.client.model.geom.ModelLayerLocation;

public class NiftyCartsModelLayers {
    public static final ModelLayerLocation ANIMAL_CART = main("animal_cart");
    public static final ModelLayerLocation PLOW = main("plow");
    public static final ModelLayerLocation SUPPLY_CART = main("supply_cart");
    public static final ModelLayerLocation HAND_CART = main("hand_cart");
    public static final ModelLayerLocation SEED_DRILL = main("seed_drill");
    public static final ModelLayerLocation REAPER = main("reaper");
    public static final ModelLayerLocation WAGON = main("wagon");
    public static final ModelLayerLocation WAGON_ROOF = main("wagon_roof");
    public static final ModelLayerLocation WAGON_CHEST = main("wagon_chest");

    @SuppressWarnings("ConfusingMainMethod")
    private static ModelLayerLocation main(String name) {
        return layer(name, "main");
    }

    @SuppressWarnings("SameParameterValue")
    private static ModelLayerLocation layer(String name, String layer) {
        return new ModelLayerLocation(NiftyCarts.resLoc(name), layer);
    }
}
