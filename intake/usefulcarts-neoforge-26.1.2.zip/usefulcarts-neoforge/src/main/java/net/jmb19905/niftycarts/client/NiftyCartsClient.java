package net.jmb19905.niftycarts.client;

import com.google.common.collect.ImmutableMap;
import com.mojang.blaze3d.platform.InputConstants;
import net.jmb19905.niftycarts.NiftyCarts;
import net.jmb19905.niftycarts.NiftyCartsConfig;
import net.jmb19905.niftycarts.client.renderer.NiftyCartsModelLayers;
import net.jmb19905.niftycarts.client.renderer.entity.*;
import net.jmb19905.niftycarts.client.renderer.entity.model.*;
import net.jmb19905.niftycarts.client.screen.WagonScreen;
import net.jmb19905.niftycarts.client.screen.PlowScreen;
import net.jmb19905.niftycarts.client.screen.SeedDrillScreen;
import net.jmb19905.niftycarts.item.CartItem;
import net.jmb19905.niftycarts.network.clientbound.UpdateDrawnPayload;
import net.jmb19905.niftycarts.network.serverbound.ActionKeyPayload;
import net.jmb19905.niftycarts.network.serverbound.ToggleSlowPayload;
import net.jmb19905.niftycarts.util.NiftyWorld;
import net.minecraft.ChatFormatting;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.state.properties.WoodType;
import org.jetbrains.annotations.NotNull;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import net.neoforged.neoforge.client.network.ClientPacketDistributor;
import net.neoforged.neoforge.client.network.event.RegisterClientPayloadHandlersEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.player.ItemTooltipEvent;
import org.lwjgl.glfw.GLFW;


@Mod(value = NiftyCarts.MOD_ID, dist = Dist.CLIENT)
public class NiftyCartsClient {

    public static final ImmutableMap<@NotNull WoodType, @NotNull String> LOG_NAME_OVERRIDE = ImmutableMap.of(
            WoodType.CRIMSON, "stem",
            WoodType.WARPED, "stem",
            WoodType.BAMBOO, "block"
    );

	private static final KeyMapping.Category KEY_CATEGORY = new KeyMapping.Category(NiftyCarts.resLoc("usefulcarts"));

	private static final KeyMapping actionKeyMapping = new KeyMapping(
			"key.usefulcarts.action", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_R, KEY_CATEGORY);
	public static final KeyMapping toggleSlowMapping = new KeyMapping(
			"key.usefulcarts.slow", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_Z, KEY_CATEGORY);

	public NiftyCartsClient(IEventBus modBus) {
		// Client config is registered by the common constructor (NiftyCarts) so the spec exists on both sides.
		modBus.addListener(NiftyCartsClient::onRegisterRenderers);
		modBus.addListener(NiftyCartsClient::onRegisterLayers);
		modBus.addListener(NiftyCartsClient::onRegisterScreens);
		modBus.addListener(NiftyCartsClient::onRegisterKeys);
		modBus.addListener(NiftyCartsClient::onRegisterClientPayloads);

		NeoForge.EVENT_BUS.addListener(NiftyCartsClient::onTooltip);
		NeoForge.EVENT_BUS.addListener(NiftyCartsClient::onClientTick);
	}

	private static void onRegisterClientPayloads(RegisterClientPayloadHandlersEvent event) {
		// NeoForge runs payload handlers on the main thread by default, so no execute() hop is needed.
		event.register(UpdateDrawnPayload.TYPE, (payload, ctx) -> {
			var level = Minecraft.getInstance().level;
			if (level != null) UpdateDrawnPayload.handle(payload, level);
		});
	}

	private static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(NiftyCarts.SUPPLY_CART_ENTITY, SupplyCartRenderer::new);
		event.registerEntityRenderer(NiftyCarts.ANIMAL_CART_ENTITY, AnimalCartRenderer::new);
		event.registerEntityRenderer(NiftyCarts.PLOW_ENTITY, PlowRenderer::new);
		event.registerEntityRenderer(NiftyCarts.HAND_CART_ENTITY, HandCartRenderer::new);
		event.registerEntityRenderer(NiftyCarts.SEED_DRILL_ENTITY, SeedDrillRenderer::new);
		event.registerEntityRenderer(NiftyCarts.REAPER_ENTITY, ReaperRenderer::new);
		event.registerEntityRenderer(NiftyCarts.WAGON_ENTITY, WagonRenderer::new);
		event.registerEntityRenderer(NiftyCarts.POSTILION_ENTITY, PostilionRenderer::new);
	}

	private static void onRegisterLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(NiftyCartsModelLayers.SUPPLY_CART, SupplyCartModel::createLayer);
		event.registerLayerDefinition(NiftyCartsModelLayers.ANIMAL_CART, AnimalCartModel::createLayer);
		event.registerLayerDefinition(NiftyCartsModelLayers.PLOW, PlowModel::createLayer);
		event.registerLayerDefinition(NiftyCartsModelLayers.HAND_CART, HandCartModel::createLayer);
		event.registerLayerDefinition(NiftyCartsModelLayers.SEED_DRILL, SeedDrillModel::createLayer);
		event.registerLayerDefinition(NiftyCartsModelLayers.REAPER, ReaperModel::createLayer);
		event.registerLayerDefinition(NiftyCartsModelLayers.WAGON, WagonModel::createLayer);
		event.registerLayerDefinition(NiftyCartsModelLayers.WAGON_ROOF, WagonRoofModel::createRoofLayer);
		event.registerLayerDefinition(NiftyCartsModelLayers.WAGON_CHEST, WagonModel::createChestLayer);
	}

	private static void onRegisterScreens(RegisterMenuScreensEvent event) {
		event.register(NiftyCarts.PLOW_MENU_TYPE, PlowScreen::new);
		event.register(NiftyCarts.SEED_DRILL_MENU_TYPE, SeedDrillScreen::new);
		event.register(NiftyCarts.WAGON_9x4_MENU_TYPE, WagonScreen::new);
		event.register(NiftyCarts.WAGON_9x8_MENU_TYPE, WagonScreen::new);
		event.register(NiftyCarts.WAGON_12x9_MENU_TYPE, WagonScreen::new);
	}

	private static void onRegisterKeys(RegisterKeyMappingsEvent event) {
		event.registerCategory(KEY_CATEGORY);
		event.register(actionKeyMapping);
		event.register(toggleSlowMapping);
	}

	private static void onTooltip(ItemTooltipEvent event) {
		if (event.getItemStack().getItem() instanceof CartItem cart) {
			var lines = event.getToolTip();
			if (!Minecraft.getInstance().hasShiftDown()) {
				lines.add(Component.translatable("item.cart.press_shift_tooltip").withStyle(ChatFormatting.GRAY));
			} else {
				lines.add(Component.translatable("item." + cart.getCartType() + ".tooltip1").withStyle(ChatFormatting.GRAY));
				lines.add(Component.translatable("item." + cart.getCartType() + ".tooltip2").withStyle(ChatFormatting.GRAY));
			}
		}
	}

	private static void onClientTick(ClientTickEvent.Post event) {
		final Minecraft client = Minecraft.getInstance();
		while (actionKeyMapping.consumeClick()) {
			ClientPacketDistributor.sendToServer(new ActionKeyPayload());
		}
		var player = client.player;
		if (player != null) {
			while (toggleSlowMapping.consumeClick()) {
				if (player.getControlledVehicle() != null && ToggleSlowPayload.isSlowable(player.getControlledVehicle())) {
					if (!ToggleSlowPayload.isSlow(player.getControlledVehicle())) {
						player.sendOverlayMessage(Component.translatable("message.usefulcarts.slow_toggled_on", toggleSlowMapping.getTranslatedKeyMessage()));
					} else {
						player.sendOverlayMessage(Component.translatable("message.usefulcarts.slow_toggled_off", toggleSlowMapping.getTranslatedKeyMessage()));
					}
				}
				ClientPacketDistributor.sendToServer(new ToggleSlowPayload());
				KeyMapping.set(toggleSlowMapping.getDefaultKey(), false);
			}
		}
		if (!client.isPaused() && client.level != null) {
			NiftyWorld.getClient().tick(client.level);
		}
	}
}
