> **NeoForge 26.1.2 port** of UsefulCarts. See PORTING.md for what changed.

# UsefulCarts

UsefulCarts adds horse-drawn and hand-pulled carts for travel, shipping, and farming.

It is an unofficial version port of [NiftyCarts](https://github.com/jmb05/nifty-carts) (by jmb05,
itself a Fabric port of [AstikorCarts](https://github.com/issork/astikor-carts) by MennoMax) to newer
Minecraft. All original code and assets belong to their authors; this project only updates the mod to
run on the latest Minecraft. Licensed under MIT (original copyright retained — see LICENSE).
