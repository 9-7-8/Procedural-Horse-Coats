# UsefulCarts: Fabric -> NeoForge 26.1.2 port notes

Source: https://github.com/Andrewwwwwwwwwwwwwww/usefulcarts-mc26.1.2 (commit 1b66a25), MIT.
Lineage: AstikorCarts (MennoMax) -> NiftyCarts (jmb05) -> UsefulCarts -> this.

## Status
Written against NeoForge's 26.1.x source and the official 26.1 MDK, and syntax-checked.
NOT yet compiled against the game jars, so expect a handful of small compile fixes on first build.

## Before first build
Set `neo_version` in gradle.properties to a real 26.1.2 NeoForge build.

## What changed
Build: Fabric Loom -> ModDevGradle 2.0.147 (Gradle 9.2.1 wrapper from the MDK), single source set.
Metadata: fabric.mod.json -> src/main/templates/META-INF/neoforge.mods.toml.
Access widener -> META-INF/accesstransformer.cfg (field/class entries) plus mixin/EntityInvoker.java
  for Entity.makeBoundingBox and setRot, since AT-widening overridable protected methods breaks
  vanilla subclasses. Mob.goalSelector/targetSelector are already public in NeoForge.
Config: legacy net.minecraftforge ForgeConfigSpec (Forge Config API Port shim) -> ModConfigSpec,
  registered through ModContainer. Forge Config API Port and Sodium dependencies dropped.
Registration: static-initializer Registry.register calls moved into a RegisterEvent handler
  (NeoForge keeps registries frozen during mod construction). The public static fields keep their
  names, so no other class needed edits. CART_PULL_CM is filled after entity types register.
Networking: payload ids moved from minecraft:usefulcarts_* to usefulcarts:* (NeoForge refuses the
  minecraft namespace). Fabric networking -> PayloadRegistrar / RegisterClientPayloadHandlersEvent /
  PacketDistributor / ClientPacketDistributor. Protocol version "1".
Events: Fabric callbacks -> ServerTickEvent.Post, ServerStarted/StoppedEvent, EntityJoinLevelEvent
  (server side only, matching Fabric's ENTITY_LOAD), PlayerInteractEvent.EntityInteract,
  EntityAttributeCreationEvent, ItemTooltipEvent, ClientTickEvent.Post, EntityRenderersEvent,
  RegisterMenuScreensEvent, RegisterKeyMappingsEvent (with registerCategory).

## Behavior fix (upstream bug)
CartInterpolationHandler lerped the Y and Z velocity from the X component (copy-paste error).
Now uses .y and .z. Revert those two lines if you want byte-identical behavior with the Fabric build.

## Not touched
All 7 mixins still target unpatched regions of the vanilla methods in NeoForge 26.1.x.
Entity, renderer, model, menu, and screen code is unchanged.
